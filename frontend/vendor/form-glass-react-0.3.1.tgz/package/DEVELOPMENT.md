# FORM Glass UI — Development and integration contract

Package version: 0.3.1. Updated: 2026-10-05.

## Application API — start here

Read the package's `AGENT-START.md` first. Application code uses `GlassPanel`,
`GlassButton`, `GlassLink`, `GlassInput`, `GlassTextarea`, `GlassDialog`,
`GlassDisclosure`, `GlassTabs`, and `GlassContentSwitch`. Managed components own
secondary material, animation preparation, displayed state and exit presence.
Keep dialog/disclosure/switch components mounted and update their state props.
Do not add your own reveal callbacks, animation timers, or conditional unmounting.

The receiving agent follows `AGENT-START.md` and finishes with `ACCEPTANCE.md`.
The latter defines browser scenarios and distinguishes documentation gaps, shared
runtime bugs and consumer deviations. Ship both files in every archive. Keep
`docs/GLASS-UI-DEVELOPMENT.md` canonical: the packaging script copies this file to
`DEVELOPMENT.md`; do not maintain a separate generated version by hand.

In 0.3.0, primary `GlassPanel`, `GlassDialog` and `GlassDisclosure` surfaces use
all-edge fadeoff by default. Favor this default in application examples. Managed
dialog/disclosure content has 32px padding for the 32px / −16px feather preset.
Panel layouts should reserve comparable space. Each managed surface accepts
`fade` for directional edges or an explicit `[]` hard-edge opt-out. Secondary
actions/fields and the compact aligned dropdown remain non-feathered; foreground
fading follows the containing primary surface. Do not clip its exterior feather.

The provider exposes `--form-glass-outset` for exterior layout clearance. It is
42px at the defaults: ceil(3 × blur + 2) plus the largest positive distance+mid
across active channel feathers. Page gutters of `calc(var(--form-glass-outset,
42px) + 2px)` avoid renderer-induced horizontal overflow. This exterior footprint
is separate from the 32px content inset. Verify both narrow and wide viewports.

Version 0.2 makes ordinary public buttons/links secondary regardless of React
nesting, and removes their material/fade overrides from the application API. Use
`GlassSurfaceButton material="surface" data-glass-specimen=""` only for intentional
primary-surface specimens. Provider context also applies the control recipe to
switches, selects and handles outside a panel. The original demo's internal
components retain their explicit specimen behavior.

Enable `GlassProvider diagnostics` for integration warnings. `auditGlassUI(root)`
returns bare-control, primary-action and unmanaged-dialog issues for consumer
checks. It is not an animation verifier. Exercise open/close/reversal and inspect
the first/final visible frames in the browser. The sections below document the
underlying engine and advanced integrations, not required application setup.

## Source of truth and reproducibility

The demo and package compile the **same** component and material sources. Do not
recreate this style from a screenshot or approximate it with a translucent fill.
Install the versioned archive and use its exported components, CSS and presets.
Commit the package dependency and lockfile in the receiving project. For an agent,
use this instruction:

> Use @form-glass/react 0.3.1 and its styles.css with one GlassProvider. Follow its
> AGENT-START.md application contract. Use managed dialogs, disclosures, tabs and
> content switches rather than assembling motion from low-level callbacks.
> Preserve material recipes, fade functions, switch light, dropdown geometry,
> Doppler profile and shared animation timings. Do not substitute native widgets
> or recreate the material CSS. Change settings through the provider's public API.

`src/styles/GlassMaterial.tsx`, `glass.ts`, `glassFade.ts` and `glass.css` are the
canonical upstream material. The library build adapts the **CSS root selector**
so the consumer's mount ID is irrelevant and defers the upstream module's two
document-initialization calls to GlassProvider. Importing the package therefore
does not require a DOM or mutate the page. Source material equations and parameters
stay shared. The packed source maps retain the implementation.

## Commands and outputs

From the source repository:

```sh
npm run check:glass
npm run build:ui
npm run pack:ui
npm run test:ui-package
```

- `build:ui`: ESM, CommonJS, CSS, inline grain asset and TypeScript declarations in
  `packages/form-glass/dist`, plus bundled documentation, example and attribution.
- `pack:ui`: build and generate `releases/form-glass-react-0.3.1.tgz`.
- `test:ui-package`: installs that archive into `artifacts/package-consumer`, checks
  both JS entry points, exported defaults and declarations, then builds the example
  against the installed package. The smoke fixture reuses already installed React
  and toolchain dependencies from the parent workspace so the test works offline.
- `npm run build`: builds the original four-page showcase separately.

The local package is private; these commands never publish it. Increment the
version in `packages/form-glass/package.json` before distributing an intentional
API or visual change. Keep a project's existing archive/version until migration is
verified. The source repository's lockfile pins the current build toolchain.

## Runtime ownership

Mount exactly one `GlassProvider`. It renders an unfiltered
`[data-form-glass-root]` wrapper and owns document-level glass/theme settings while
mounted. A second provider throws rather than silently overriding the first.
Unmount restores the prior glass CSS variables, attributes and theme class.
The runtime is client-only; in Next.js use a client component loaded without SSR
for the glass scene. React/ReactDOM 18.3.1 is the tested peer version.

Import `@form-glass/react/styles.css` once, after your reset and before project
layout overrides. The package supplies typography and control furniture, not page
layout, navigation, photos or the FORM wordmark. Background photos remain the
application's responsibility, including their licensing and credits.

Do not apply `filter`, container opacity, masks or clipping to the provider or a
parent holding multiple live glass surfaces. That changes the backdrop sampling
root. Solid surfaces clip their filtering span itself; faded surfaces keep their
extended alpha field. Place the fixed scene behind the glass without an intervening
opaque background. Components default to glass layer 24; contact source paint is
layer 22, contact handles 30. Set `--form-glass-layer` or the surface's `zIndex` for
your own overlay hierarchy. Avoid transformed ancestors around viewport-fixed
draggable/contact elements and dropdowns.

## Provider settings

| Prop | Meaning / default |
| --- | --- |
| `theme` | `light` or `dark`; defaults to light |
| `enabled` | enable material, true |
| `values` | partial `GlassValues` merged into that theme's preset |
| `curve` | `smootherstep`, `softmax`, or `linear`; smootherstep |
| `textColor` | theme, black, white, or invert; theme |
| `fadeContents` | true; foreground follows the blur feather |
| `refractionEnabled` | **false** |
| `refraction` | optional overrides of the saved mirror preset |
| `distortControls` | false; nested controls retain their material |
| `animations` | complete `AnimationSettings`, shared appearance/disappearance |

`useGlass()` returns resolved settings. Keep edits in application state and pass
them to the provider. `values.brightness` is signed percent (0 neutral), `contrast`
is a multiplier (1 neutral), and `blur` is CSS pixels. Light preset is 8 / +40 / 0.6;
dark is 8 / −40 / 1.4. Grain is 25%; 100 on this refined UI scale equals 10% of the
old noise scale. Each channel has distance 32 / mid −16, independently editable.
The exemption mid is a different setting and defaults to **−32**.

Refraction's retained opt-in preset is amount 100%, axis 16px, bend 30%, span 1px,
outer blend 8px, curve 1, map softness .35px, square optical corner 3px. It acts only
on selected fade edges. Rounded corners fold once along the arc normal.

## Geometry and foreground

```tsx
<Glass fade={[]} /> // Solid round rectangle
<Glass shape="flush" /> // Square, all four edges fade
<Glass shape="capsule" />
<Glass shape="flush" fade={['top','bottom']} />
<Glass shape="flush" fade={['left','right']} />
<Glass fade={['top']} style={{
  '--glass-corner-tl':'0px','--glass-corner-tr':'0px',
  '--glass-corner-br':'12px','--glass-corner-bl':'12px'
} as React.CSSProperties} />
```

Layout dimensions are application-owned; use `aspectRatio:'3 / 2'` to reproduce
the laboratory's specimen ratio. Empty fade edges stay sharp; the global fade
settings do not change them. All-edge square mirror rounding is optical-only.
Nested buttons automatically use compensated control tone and empty fade edges.
Do not stack an extra opaque background, tint, border or shadow over the material.

`Glass` / `GlassButton` recursively wrap literal foreground in `glass-text`, which
lets fade and inverse text work independently of backdrop filters. A custom child
component can return `foregroundText(<YourMarkup/>)` when it emits unwrapped text.
Do not wrap photograph/SVG artwork as text. Invert uses the actual background under
the glyph, not a fixed swapped text color.

## Controls

- `GlassButton`, `GlassLink`: retain native semantic props and shape, with fixed
  secondary material and empty fade edges. Material/fade overrides are not public.
- `GlassField`: wrapper for an input; the numeric field's whole bubble owns focus.
- `GlassSwitch`: `label`, `checked`, `onChange`; text-only bubble, diffuse green on
  light and orange off light, with a moving internal light source.
- `GlassSelect`: `label`, `value`, `options`, `onChange`, optional `disabled`.
  The selected row stays exactly on the trigger and other rows unfold in one
  direction. Rows inherit the trigger's height, radius, padding and typography.
  Keyboard navigation, typeahead, Escape and return focus are included.
- `ParameterControl`: label/value/min/max/step/unit/onChange. Numeric editing
  remains direct; Doppler range dragging previews locally and commits on release.
- `DopplerRange`: native range semantics, circular-cut flares, velocity-based tail,
  spring return, shortened middle line and endpoint lobe suppression. Do not place
  another special glass capsule behind this line-only control.
- `InstrumentNumber`: integer `value`, optional minimum `digits` (default 2).
- `GlassScrollArea`: use `height={370}` or `maxHeight="50vh"` to size its viewport;
  `viewportClassName` remains available for responsive CSS. Its 3px thumb has a larger
  invisible pointer target. `GlassPageScrollbar` opts the whole page into the same
  appearance. Scroll edges fade in the native scroll timeline where supported.
- `GlassDraggable`: controlled `position` and `onPositionChange`, optional label
  and `bounds` (viewport or none). Default bounds keep it in view; arrow keys move
  8px and Shift+arrow moves 20px. It supports the same Glass geometry props.
  The label is visible handle text: keep it short. Initial mount and window/surface
  resize clamp the controlled position, including feather bounds, via the callback.
  Oversized content still needs responsive width/height. Do not add a consumer
  resize handler to compensate for the package's viewport-bounds behavior.

## Exempt contact objects

```tsx
const [objects,setObjects] = useState(()=>[createContactObject({
  id:'photo', label:'Photograph', src:'/images/photo.jpg',
  x:200, y:140, width:180, height:120
})]);
// Inside GlassProvider:
<GlassContactObjects objects={objects} onChange={setObjects}/>
```

`createContactObject` supplies exempt=true, strength=100, distance=32, mid=−32.
Override those fields per object as needed. `selectedId` / `onSelect` can be
controlled separately. Coordinates and dimensions are viewport CSS pixels.
Images resolve against the receiving document URL and absolute/data URLs also
work. Same-origin image URLs are recommended. Source URLs must allow browser
loading; the package does not proxy external media.

Each field only reduces that object's blur, brightness and contrast. It never
clears the background or a different object. Overlapping glasses carry the prior
object result into the next stage; grain continues to affect the exempt object.
The label is an ordinary glass handle and remains subject to covering glass.

## Reveal and content transitions

`GlassDialog.className` targets its inner glass surface. It does not size the
native dialog wrapper (560px maximum, 20px viewport gutters). Avoid a wider inner
surface; use responsive child layout. For tall bodies use `GlassScrollArea` with
`maxHeight="55dvh"` inside the dialog, leaving its header and close action visible.

The preset is blur-out 350ms, fade-out 150ms, blur limit 16px, expand and contract
250ms. Managed dialogs start at the focused trigger (or `originRef`), and return
there on close. Without a trigger the centred fallback is 10% per axis. Seed
dimensions never fall below twice the corner radius; inward feather adds room
so the visible seed cannot disappear. Appearance reuses the timings in reverse:
fade in, then focus. Old-content disappearance, glass movement and new-content
appearance run sequentially. The foreground has no layout boxes during shell
motion. The normal 500ms + 250ms + 500ms transition is deliberately longer than
the former concurrent transition. A newly opened dialog has no outgoing content;
a closing dialog has no incoming content. Smootherstep is monotonic, without a bounce.

Advanced engine integration only (applications use `GlassDisclosure`):

```tsx
const [open,setOpen] = useState(false);
const [shown,setShown] = useState(false);
<Glass reveal={open}
  className={shown?'expanded':'compact'}
  onRevealPrepare={setShown} onRevealCommit={setShown}>
  {shown && <div>Expanded controls</div>}
  <GlassButton onClick={()=>setOpen(!open)}>Parameters</GlassButton>
</Glass>
```

Do not unmount the shell when closing; use `onRevealEnd(false)` for final removal.
`revealOriginBox` can return width/height plus optional viewport left/top for a
trigger-sized start shape. Without it, compact in-flow geometry or fallback
proportions apply. Dropdowns pin their selected row at the top/bottom origin.
Real width/height and translation animate together; corners retain their radius.
In-flow disclosure resizing also drives stretched sibling panels, whose content
joins the same blur/fade clock. Geometry is ready before the first visible frame.
The peer scope is the nearest grid row or flex layout, not every panel in the
document. Unrelated cards do not disappear. Disclosure focus is restored after
motion unless the user chose another focus target in the meantime.
`useContentTransition(key, ref, swap)` animates complete old/new content for page
or tab changes; `swap` commits the requested view. It also accepts an optional CSS
selector for related foreground outside the main root. Keep settings stable while
a transition is playing; the animation samples them at its start.

The live foreground includes labels, borders, values, canvases and inline SVG.
There are no duplicate control trees. After disappearance, the target layout is
measured once while transparent. During motion the foreground has `display:none`;
React instances and control values remain mounted. Layout and foreground masks
are restored while transparent before appearance. Native timelines start only
after preparation, so preparation does not consume the requested duration.
Reduced-motion preferences bypass movement and transitions.

Feathered surfaces reuse the original SVG alpha field as a native nine-slice mask
on the existing filtering element. Corners translate without resizing, edge strips
stretch along one axis and the opaque centre stretches along both. Each independent
material channel has its own fixed slice bounds. The smallest shell respects the
corner diameter and all channel inset constraints. The object exemption compositor
uses the same nine rectangles. Browsers lacking native mask-box-image retain the
full-field update path. Solid surfaces retain their native rounded clip.

Refraction-off does not subscribe to the global refraction geometry observer.
The lerp renderer never writes unused progressive core-size variables;
geometry notifications still update object paint. Object exemption follows the moving shell through a bounded animation loop that
stops at settling. Grain reuses the existing decoded 128px texture and cached
canvas patterns; it does not allocate or upload a new full-screen texture per frame.
The original material filters, source images and independent fades are preserved.

## Validation and maintenance

Run the package smoke test after every public API or stylesheet change, then
visually check its example at `http://127.0.0.1:5181`: non-root mount, theme switch,
dropdown row alignment, keyboard selection, range release, scroll rail, directional
fade, counter, draggable panel, contact object and reset/default values. Test
overlapping panes, open/close interruptions and reduced motion for animation work.

The canonical checks and mathematical tests remain in `scripts/`: glass fade,
material fade, refraction, contact field/blend, range shape/spring, scroll fade and
scrollbar geometry. Public type checking and actual consumer bundling catch missing
exports, broken declaration paths and asset assumptions that source-only checks miss.

Chromium/Edge is the reference rendering engine. Popover, backdrop-filter, SVG
filter and Web Animations support is required; optional scroll timelines have a
fallback. Other browser engines and React major versions need explicit validation.
Large animated panes can still have preparation/compositing stalls, especially with
refraction or many nested controls. **120fps is an optimization target, not a
guarantee in this release.** Keep refraction off for baseline interaction tests.
No idle rendering loop is added by the provider.

Source attribution is in the package NOTICE and upstream Apache license. The
package intentionally includes no showcase photography, routing, site layout or
remote service dependency. It does include the grain resource and example graphic.


## Performance acceptance

Use the original `http://127.0.0.1:5180/#laboratory` as the acceptance scene.
The smaller package-consumer pages are integration checks, not performance proof.
Keep the complex photo, all gallery controls, grain, contact objects and enabled
feathering. Refraction remains disabled by default. Record viewport and settings.

In development, `?profileGlass=1#laboratory` enables bounded timing-only recording
in `#performance-probe`. It performs no per-frame layout reads. Report the active
geometry window separately from startup delay and the longer content transition;
never average idle frames into a 120fps claim. `?profile=glass` is the older geometry
inspection probe and adds DOM reads, so do not combine it with timing measurements.

Historical implementation and performance measurements belong in the repository's
`docs/GLASS-PACKAGE-VALIDATION.md`. They are not application integration recipes;
the sequential live-foreground lifecycle above is the current contract.


## Sequential motion release (0.3.0)

The sequential lifecycle above supersedes the concurrent-copy behavior in 0.2.x.
Use the original full Laboratory on port 5180 for performance acceptance and its
Architecture project dialog for full-feather corner checks. Do not substitute a
simplified consumer page. Timing probe: `?profileGlass=1#laboratory` (2.6s bounded
recording). Geometry probe: `?profile=glass#laboratory`; it reads layout every
frame and is for correctness only, not FPS claims. Geometry samples expose
`foregroundBoxes`, `copies`, and `nineSlice`. Moving should have zero foreground
boxes and zero paint copies. Test close/reopen, dropdown anchoring and keyboard
selection, inverted text, independent fades, contact overlaps and refraction on.
Run `node --test scripts/nine-slice.test.mjs` with the existing mathematical tests.
