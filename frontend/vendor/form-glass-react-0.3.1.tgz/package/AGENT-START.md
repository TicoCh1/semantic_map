# FORM Glass 0.3 — Application integration

Build with the public components below. They own the material hierarchy and motion.
Your application owns content, layout and business state. Import `styles.css` once
and keep one `GlassProvider` mounted. Use React/ReactDOM 18.3.1 and a browser client.
Application panels/actions/inputs/selects/switches throw a clear error if the
provider is missing, instead of silently rendering with incomplete settings.

## Integration workflow

1. Read this file, then use the exported TypeScript declarations for exact props.
2. Map each interaction to the component table below before building the layout.
3. Install the archive, import the CSS once, and keep one provider mounted.
4. Build application state and layout around the managed components. Start with
   default feathering and refraction off; do not tune away an integration problem.
5. Run type checking/build, then complete [ACCEPTANCE.md](ACCEPTANCE.md). Record
   observed behavior and any untested paths. A successful build alone is not done.

The package owns material and motion; the application owns data and final layout.
Do not animate the same geometry with a second CSS/JS system. In 0.3, transitions
are sequential: old contents disappear, the empty shell moves, new contents appear.
The engine removes foreground layout boxes during the middle phase and restores
the final layout while transparent. Applications do not need to implement this.

## Choose a component by task

| Task | Component | What it handles |
| --- | --- | --- |
| Page card / surface | `GlassPanel` | Primary material, foreground treatment |
| Action / link | `GlassButton`, `GlassLink` | Secondary material, no edge feather, native semantics |
| Text / numeric input | `GlassInput` | Label, secondary field, focus style |
| Multiline input | `GlassTextarea` | Label, secondary field, focus style |
| On/off state | `GlassSwitch` | Secondary bubble, animated state light |
| Choice dropdown | `GlassSelect` | Secondary trigger/rows, aligned menu, enter/exit, keyboard |
| Modal | `GlassDialog` | Presence, blur/fade, shell motion, Escape, focus return |
| Expandable panel | `GlassDisclosure` | Compact/expanded layout and complete enter/exit |
| Tabs | `GlassTabs` | Secondary tab actions, keyboard, animated content replacement |
| Route / other view changes | `GlassContentSwitch` | Retained outgoing view and animated swap |
| Number + range | `ParameterControl` | Editable number, range preview, release commit |
| Scroll | `GlassScrollArea`, `GlassPageScrollbar` | Theme-matched scrollbar and keyboard |
| Drag | `GlassDraggable` | Pointer capture, controlled position, keyboard movement |

Actions use the **secondary control recipe even when placed directly under the
provider**, so moving a toolbar out of a panel does not change its material.
Do not reproduce these controls with native buttons/fields plus CSS classes.
`GlassButton` and `GlassLink` intentionally do not accept `material` or `fade`.
Use CSS for spacing and layout, not replacement fills, filters or material recipes.

## Complete example

**Enable fadeoff for primary surfaces by default.** `GlassPanel`, `GlassDialog`
and `GlassDisclosure` fade all four edges when `fade` is omitted. Prefer that
default in application layouts and examples; do not routinely add `fade={[]}`.
The preset uses smootherstep, distance 32px and mid −16px independently for blur,
brightness and contrast. `fadeContents` is enabled on the provider.

Use `fade={['top','bottom']}` or `fade={['left','right']}` for intentional directional
surfaces. Reserve `fade={[]}` for an explicit hard-edge design requirement.
Buttons, inputs, switch bubbles and dropdown rows remain secondary, non-feathered
controls; their containing surface handles foreground fading. The compact aligned
dropdown shell also retains its hard-edge recipe.

Give primary panel content approximately 32px of inset with this preset and leave
room between surfaces for their feathering. Managed dialogs/disclosures supply that
padding. Do not clip the surrounding layout with `overflow:hidden`; constrain only
the intended scroll viewport. Check text, focus indicators and nested controls near
the fading edges at the smallest supported size.

**Interior padding is not the exterior footprint.** The default renderer extends
42px outside its surface (26px blur sampling guard plus 16px feather extent).
Use at least 44px page gutters at the defaults, including on mobile, or use the
provider's live `--form-glass-outset` token so parameter changes remain safe:

```css
.page-layout { padding-inline: calc(var(--form-glass-outset, 42px) + 2px); }
```

This token describes the conservative renderer footprint, not a visible border.
Do not hide horizontal overflow to conceal insufficient space. The 32px content
inset is additional space inside each panel.

```tsx
import {useState} from 'react';
import {
  GlassProvider, GlassPanel, GlassButton, GlassInput,
  GlassDialog, GlassDisclosure, GlassTabs, GlassPageScrollbar,
} from '@form-glass/react';
import '@form-glass/react/styles.css';

export function App() {
  const [open,setOpen] = useState(false);
  const [expanded,setExpanded] = useState(false);
  const [tab,setTab] = useState('overview');
  const [name,setName] = useState('');
  return <GlassProvider diagnostics>
    <div className="scene-background" />
    <main className="page-layout">
      <GlassPanel style={{padding:32}}>
        <h1>Project library</h1>
        <GlassInput label="Search projects" type="search"
          value={name} onChange={event=>setName(event.target.value)}/>
        <GlassButton onClick={()=>setOpen(true)}>New project</GlassButton>
        <GlassTabs label="Project views" value={tab} onValueChange={setTab} tabs={[
          {value:'overview',label:'Overview',content:<p>Project overview.</p>},
          {value:'activity',label:'Activity',content:<p>Recent activity.</p>},
        ]}/>
      </GlassPanel>
      <GlassDisclosure label="Display options" open={expanded} onOpenChange={setExpanded}>
        <p>Additional options.</p>
      </GlassDisclosure>
    </main>
    <GlassDialog title="New project" open={open} onOpenChange={setOpen}>
      <GlassInput label="Project name" value={name} onChange={e=>setName(e.target.value)}/>
      <GlassButton onClick={()=>setOpen(false)}>Save</GlassButton>
    </GlassDialog>
    <GlassPageScrollbar/>
  </GlassProvider>;
}
```

Supply a visible background behind the surfaces. Give the page its own responsive
layout and spacing. Do not put `opacity`, `filter`, `mask`, or `transform` on the
provider or layout ancestors of live surfaces: they affect backdrop/overlay roots.

Set scrolling dimensions directly on the component:

```tsx
<GlassScrollArea height={370} label="Project list">{items}</GlassScrollArea>
```

`height` and `maxHeight` size the actual scrolling viewport, in CSS pixels for a
number or a CSS length string. `className` styles its outer container;
`viewportClassName` is available for advanced responsive viewport styling.
Setting a height on the outer class alone does not establish scrolling.

## Motion is part of the component

Keep `GlassDialog` and `GlassDisclosure` mounted and change their `open` prop. Do
not write `{open && <GlassDialog .../>}`: immediate unmount prevents any library
from playing an exit. The managed components keep the exiting paint alive and
perform the final hide themselves. You do not need `reveal`, animation callbacks,
timeouts, duplicate content, CSS keyframes or an external presence library.

For a view selector or router:

```tsx
<GlassContentSwitch value={page} render={key =>
  key === 'home' ? <Home/> : <Settings/>
}/>
```

Use the callback's **key**, not the outer `page`, to select content. Keep the switch
itself mounted; don't assign `key={page}` to it. The wrapper owns when the displayed
view changes. Include everything that should transition in its returned content.
Nested opaque/custom ancestors and portals require explicit composition review.

Default timing: outgoing blur 350ms then fade 150ms; incoming fade then focus using
the same durations; shell expand/contract 250ms. The phases run in order: disappear, glass motion, appear. Default
easing is smootherstep. A dialog automatically captures the focused trigger's
rectangle before opening, grows from there, and closes to the same rectangle.
For programmatic opening, pass `originRef` pointing to a visible origin element.
Without a trigger it grows from a centred seed (10% per axis). Every seed is
clamped to at least the corner diameter, with extra space for inward fadeoff;
never configure an invisible point or a 100% no-motion seed as the standard.
The real shell dimensions change, preserving circular corners rather than
flattening them with non-uniform scale. Reduced motion bypasses animation.

`GlassDialog.className` styles its **inner glass surface**, not the native dialog.
Keep that surface at the provided width; arrange children responsively rather
than setting a larger width on the inner class. Its native container is up to
560px wide and leaves 20px on each viewport side. For tall content, place only the
body inside `GlassScrollArea maxHeight="55dvh"`, keeping heading/close accessible.

`GlassSelect` derives its seed from the selected trigger row and keeps that row
pinned. `GlassDisclosure` derives its compact box and animates actual in-flow
height: stretched panels in the same layout grow/shrink with it automatically,
including their foreground transition. Do not add consumer height/scale timers.
Only panels sharing the disclosure's grid row or flex layout participate;
unrelated cards retain their content. Keyboard focus returns to the disclosure
trigger after movement unless the user has moved focus elsewhere.

`GlassDraggable.label` is the **visible handle text**, so use a short label such
as "Move note" and put longer instructions inside the panel. With default viewport
bounds the package clamps initial and resized positions, including the feather
footprint, and reports corrections through `onPositionChange`. Keep this callback
connected to state. `bounds="none"` explicitly opts out. Choose responsive panel
dimensions that fit the viewport; position clamping cannot shrink oversized content.

## Verify before delivery

Enable `diagnostics` during integration; fix FORM Glass warnings. The same
read-only check is exported as `auditGlassUI(root)` and returns code/message/element
records. It checks bare controls, primary-material actions and unmanaged dialogs.
It does not prove animation correctness: test the following in the browser.

- Inspect a toolbar action and nested action: both have `data-glass-material="control"`.
- Inputs have a `.glass-field[data-glass-material="control"]` owner.
- Open/close modal and disclosure, including rapid reversal; verify no flash or
  leftover `[data-glass-transition-copy]` nodes after completion.
- Change tabs/views; all intended content participates in blur/fade.
- Escape closes a dialog and restores focus. Dropdown rows match the trigger.
- Inspect intermediate frames, not only the final screenshot: modal travel begins
  at its trigger, corners never collapse, dropdown first-frame geometry is ready,
  and a disclosure's affected sibling panels resize continuously in both directions.
- Exercise fast pointer dragging, numeric entry, wheel scroll and keyboard paths.
- Run type checking and production build, and record what was actually tested.

Runtime diagnostics are opt-in and not a proof that every external component is
correct. Third-party interactive widgets need an explicit adapter. An intentional
visual specimen can use `GlassSurfaceButton` with `material="surface"` and
`data-glass-specimen=""`; this is for material studies, not ordinary actions.

## Defaults and advanced APIs

Light: blur 8px, brightness +40%, contrast 0.6, black text. Dark: 8px, −40%, 1.4,
white text. Grain 25%. Refraction off. Exemption mid −32px. Reset and presets use
the exported helpers. See DEVELOPMENT.md for parameter units and advanced effects.

`Glass`, `GlassField`, `foregroundText`, and `useContentTransition` are advanced
integration tools. Prefer the managed APIs above when their task matches. They
remain available for specialized integrations; do not independently rebuild a
dialog or page transition from them for an ordinary application.
