# Consumer acceptance — FORM Glass 0.3

Use this checklist in the receiving application, with fadeoff enabled and the
default refraction-off setting. Test the actual installed archive, not source
aliases. Record browser, viewport, package version and results. Keep performance
claims separate from these integration checks.

## Static contract

- Exactly one `GlassProvider`, one CSS import, no missing-provider/runtime errors.
- `diagnostics` enabled during integration; no unresolved FORM warnings.
- Every action (including header, modal close and empty-state actions) has
  secondary material. Text/numeric fields own a secondary field bubble.
- Sliders retain their line-only profile; do not add a background bubble to them.
- Primary panels/dialogs/disclosures use default fade, or a deliberate directional
  fade. Content and focus rings remain readable inside the feather inset.
- A detailed scene is visible behind the glass. Layout CSS does not replace the
  package's material, filters, mask, corner geometry or backdrop ancestry.
- Lists use `GlassScrollArea` with an explicit viewport height/maxHeight. Pages
  that scroll include `GlassPageScrollbar`. Menus use `GlassSelect`.

## Browser interaction matrix

| Scenario | Required observations |
| --- | --- |
| Dialog open/close | Starts at the clicked/focused trigger (explicit `originRef` for a programmatic open), returns to it, no full-size first-frame flash, no square-corner frame. Seed remains at least the corner diameter. |
| Disclosure open/close | Content disappears before actual in-flow shell resizing and returns after it. Any stretched sibling surface also resizes smoothly. Check both sides of the layout, not only the disclosure. |
| Tabs / pages | Entire outgoing content blurs then fades; incoming fades then focuses. Titles, separators, icons, numbers and nested actions participate. Use the switch callback key to render the retained view. |
| Dropdown | Selected row overlaps the trigger, unfolds in one direction; rows match trigger height/radius. No clipping or square first frame. Choose an item, use arrows/Enter and Escape, verify focus return. |
| Inputs / switches / ranges | Typed state updates; switch changes state; range pointer preview commits on release. Numeric entry and keyboard also work. |
| Scrolling | Thumb is thin, theme matched and draggable. Fast scrolling does not reveal content outside its feathered viewport. No horizontal page overflow at the supported narrow width. |
| Dragging | Pointer and arrow-key movement work. Focus and text stay inside the panel. |
| Interruption | Open then Escape before completion; reopen. No stranded inert surface, hidden contents, stale overlay or duplicate controls. |
| Reduced motion | The final state remains correct without geometry animation. |

Inspect intermediate frames, not just end screenshots. In the shell-moving phase
the foreground has no layout boxes; there must be no copied transition controls.
Native modal/dialog focus, selected values and controlled application state must
remain valid after closing and reopening. Do not add timeouts to make a test pass.

## Evidence and attribution

Deliver the application source, passing type/build result, screenshots and a short
table of tested/failed/untested scenarios. Do not write "all details verified" if
only the final screenshot was inspected. A static diagnostic pass cannot certify
animation, color fidelity, clipping, keyboard behavior or performance.

When something fails, identify the responsible layer before patching:

1. **Guide gap:** the public instructions or example omitted/contradicted a needed
   rule. Fix the guide and rerun using only the revised instruction.
2. **API/runtime gap:** correct documented composition still fails. Fix the shared
   implementation and package; do not ask consumers to patch private DOM/CSS.
3. **Consumer deviation:** the documented managed API was bypassed. Replace the
   custom implementation with the public component and recheck.
4. **Environment limitation:** record what could not be tested; never count it as
   a pass or hide it by turning off fade, grain or motion.
