# FORM Glass UI — Development and integration contract

Package version: 0.1.0. Updated: 2026-10-04.

## Source of truth and reproducibility

The demo and package compile the **same** component and material sources. Do not
recreate this style from a screenshot or approximate it with a translucent fill.
Install the versioned archive and use its exported components, CSS and presets.
Commit the package dependency and lockfile in the receiving project. For an agent,
use this instruction:

> Use @form-glass/react 0.1.0 and its styles.css with one GlassProvider. Follow its
> DEVELOPMENT.md contract. Build layout and content with its exported controls.
> Preserve material recipes, fade functions, switch light, dropdown geometry,
> Doppler profile and shared animation timings. Do not substitute native widgets
> or recreate the material CSS. Change settings through the provider's public API.

`src/styles/GlassMaterial.tsx`, `glass.ts`, `glassFade.ts` and `glass.css` are the
canonical upstream material. The library build adapts the **CSS root selector**
so the consumer's mount ID is irrelevant and defers the upstream module's two
document-initialization calls to GlassProvider. Importing the package therefore
does not require a DOM or mutate the page. Source material equations and parameters
stay shared. The packed source maps retain the implementation.

## Commands and outputs

From the source repository:

```sh
npm run check:glass
npm run build:ui
npm run pack:ui
npm run test:ui-package
```

- `build:ui`: ESM, CommonJS, CSS, inline grain asset and TypeScript declarations in
  `packages/form-glass/dist`, plus bundled documentation, example and attribution.
- `pack:ui`: build and generate `releases/form-glass-react-0.1.0.tgz`.
- `test:ui-package`: installs that archive into `artifacts/package-consumer`, checks
  both JS entry points, exported defaults and declarations, then builds the example
  against the installed package. The smoke fixture reuses already installed React
  and toolchain dependencies from the parent workspace so the test works offline.
- `npm run build`: builds the original four-page showcase separately.

The local package is private; these commands never publish it. Increment the
version in `packages/form-glass/package.json` before distributing an intentional
API or visual change. Keep a project's existing archive/version until migration is
verified. The source repository's lockfile pins the current build toolchain.

## Runtime ownership

Mount exactly one `GlassProvider`. It renders an unfiltered
`[data-form-glass-root]` wrapper and owns document-level glass/theme settings while
mounted. A second provider throws rather than silently overriding the first.
Unmount restores the prior glass CSS variables, attributes and theme class.
The runtime is client-only; in Next.js use a client component loaded without SSR
for the glass scene. React/ReactDOM 18.3.1 is the tested peer version.

Import `@form-glass/react/styles.css` once, after your reset and before project
layout overrides. The package supplies typography and control furniture, not page
layout, navigation, photos or the FORM wordmark. Background photos remain the
application's responsibility, including their licensing and credits.

Do not apply `filter`, container opacity, masks or clipping to the provider or a
parent holding multiple live glass surfaces. That changes the backdrop sampling
root. Solid surfaces clip their filtering span itself; faded surfaces keep their
extended alpha field. Place the fixed scene behind the glass without an intervening
opaque background. Components default to glass layer 24; contact source paint is
layer 22, contact handles 30. Set `--form-glass-layer` or the surface's `zIndex` for
your own overlay hierarchy. Avoid transformed ancestors around viewport-fixed
draggable/contact elements and dropdowns.

## Provider settings

| Prop | Meaning / default |
| --- | --- |
| `theme` | `light` or `dark`; defaults to light |
| `enabled` | enable material, true |
| `values` | partial `GlassValues` merged into that theme's preset |
| `curve` | `smootherstep`, `softmax`, or `linear`; smootherstep |
| `textColor` | theme, black, white, or invert; theme |
| `fadeContents` | true; foreground follows the blur feather |
| `refractionEnabled` | **false** |
| `refraction` | optional overrides of the saved mirror preset |
| `distortControls` | false; nested controls retain their material |
| `animations` | complete `AnimationSettings`, shared appearance/disappearance |

`useGlass()` returns resolved settings. Keep edits in application state and pass
them to the provider. `values.brightness` is signed percent (0 neutral), `contrast`
is a multiplier (1 neutral), and `blur` is CSS pixels. Light preset is 8 / +40 / 0.6;
dark is 8 / −40 / 1.4. Grain is 25%; 100 on this refined UI scale equals 10% of the
old noise scale. Each channel has distance 32 / mid −16, independently editable.
The exemption mid is a different setting and defaults to **−32**.

Refraction's retained opt-in preset is amount 100%, axis 16px, bend 30%, span 1px,
outer blend 8px, curve 1, map softness .35px, square optical corner 3px. It acts only
on selected fade edges. Rounded corners fold once along the arc normal.

## Geometry and foreground

```tsx
<Glass fade={[]} /> // Solid round rectangle
<Glass shape="flush" /> // Square, all four edges fade
<Glass shape="capsule" />
<Glass shape="flush" fade={['top','bottom']} />
<Glass shape="flush" fade={['left','right']} />
<Glass fade={['top']} style={{
  '--glass-corner-tl':'0px','--glass-corner-tr':'0px',
  '--glass-corner-br':'12px','--glass-corner-bl':'12px'
} as React.CSSProperties} />
```

Layout dimensions are application-owned; use `aspectRatio:'3 / 2'` to reproduce
the laboratory's specimen ratio. Empty fade edges stay sharp; the global fade
settings do not change them. All-edge square mirror rounding is optical-only.
Nested buttons automatically use compensated control tone and empty fade edges.
Do not stack an extra opaque background, tint, border or shadow over the material.

`Glass` / `GlassButton` recursively wrap literal foreground in `glass-text`, which
lets fade and inverse text work independently of backdrop filters. A custom child
component can return `foregroundText(<YourMarkup/>)` when it emits unwrapped text.
Do not wrap photograph/SVG artwork as text. Invert uses the actual background under
the glyph, not a fixed swapped text color.

## Controls

- `GlassButton`, `GlassLink`: retain native semantic props and geometry props.
- `GlassField`: wrapper for an input; the numeric field's whole bubble owns focus.
- `GlassSwitch`: `label`, `checked`, `onChange`; text-only bubble, diffuse green on
  light and orange off light, with a moving internal light source.
- `GlassSelect`: `label`, `value`, `options`, `onChange`, optional `disabled`.
  The selected row stays exactly on the trigger and other rows unfold in one
  direction. Rows inherit the trigger's height, radius, padding and typography.
  Keyboard navigation, typeahead, Escape and return focus are included.
- `ParameterControl`: label/value/min/max/step/unit/onChange. Numeric editing
  remains direct; Doppler range dragging previews locally and commits on release.
- `DopplerRange`: native range semantics, circular-cut flares, velocity-based tail,
  spring return, shortened middle line and endpoint lobe suppression. Do not place
  another special glass capsule behind this line-only control.
- `InstrumentNumber`: integer `value`, optional minimum `digits` (default 2).
- `GlassScrollArea`: set height on `viewportClassName`; its 3px thumb has a larger
  invisible pointer target. `GlassPageScrollbar` opts the whole page into the same
  appearance. Scroll edges fade in the native scroll timeline where supported.
- `GlassDraggable`: controlled `position` and `onPositionChange`, optional label
  and `bounds` (viewport or none). Default bounds keep it in view; arrow keys move
  8px and Shift+arrow moves 20px. It supports the same Glass geometry props.

## Exempt contact objects

```tsx
const [objects,setObjects] = useState(()=>[createContactObject({
  id:'photo', label:'Photograph', src:'/images/photo.jpg',
  x:200, y:140, width:180, height:120
})]);
// Inside GlassProvider:
<GlassContactObjects objects={objects} onChange={setObjects}/>
```

`createContactObject` supplies exempt=true, strength=100, distance=32, mid=−32.
Override those fields per object as needed. `selectedId` / `onSelect` can be
controlled separately. Coordinates and dimensions are viewport CSS pixels.
Images resolve against the receiving document URL and absolute/data URLs also
work. Same-origin image URLs are recommended. Source URLs must allow browser
loading; the package does not proxy external media.

Each field only reduces that object's blur, brightness and contrast. It never
clears the background or a different object. Overlapping glasses carry the prior
object result into the next stage; grain continues to affect the exempt object.
The label is an ordinary glass handle and remains subject to covering glass.

## Reveal and content transitions

The preset is blur-out 350ms, fade-out 150ms, blur limit 16px, expand and contract
250ms, closed dialog dimensions 100%. Appearance reuses the timings in reverse:
fade in, then focus. Old-content disappearance, glass movement and new-content
appearance share one start frame. Smootherstep is monotonic, without a bounce.

For a persistent expandable shell:

```tsx
const [open,setOpen] = useState(false);
const [shown,setShown] = useState(false);
<Glass reveal={open} fade={[]}
  className={shown?'expanded':'compact'}
  onRevealPrepare={setShown} onRevealCommit={setShown}>
  {shown && <div>Expanded controls</div>}
  <GlassButton onClick={()=>setOpen(!open)}>Parameters</GlassButton>
</Glass>
```

Do not unmount the shell when closing; use `onRevealEnd(false)` for final removal.
`revealOriginBox` can return a width/height for a trigger-sized start shape. Without
it, dialog proportions apply. Supply the transform origin through component CSS.
`useContentTransition(key, ref, swap)` animates complete old/new content for page
or tab changes; `swap` commits the requested view. It also accepts an optional CSS
selector for related foreground outside the main root. Keep settings stable while
a transition is playing; the animation samples them at its start.

Temporary inert copies include labels, borders, values and canvas paint. Incoming
copies are transparent and blurred before attachment; actual controls stay hidden
until the final handoff. Runtime geometry/object observers exclude copies. New
timelines are prepared before the common animation clock starts, so preparation
cannot consume the requested duration. Solid filter spans keep rounded clipping
throughout scaling. Reduced-motion preferences bypass movement and transitions.

## Validation and maintenance

Run the package smoke test after every public API or stylesheet change, then
visually check its example at `http://127.0.0.1:5181`: non-root mount, theme switch,
dropdown row alignment, keyboard selection, range release, scroll rail, directional
fade, counter, draggable panel, contact object and reset/default values. Test
overlapping panes, open/close interruptions and reduced motion for animation work.

The canonical checks and mathematical tests remain in `scripts/`: glass fade,
material fade, refraction, contact field/blend, range shape/spring, scroll fade and
scrollbar geometry. Public type checking and actual consumer bundling catch missing
exports, broken declaration paths and asset assumptions that source-only checks miss.

Chromium/Edge is the reference rendering engine. Popover, backdrop-filter, SVG
filter and Web Animations support is required; optional scroll timelines have a
fallback. Other browser engines and React major versions need explicit validation.
Large animated panes can still have preparation/compositing stalls, especially with
refraction or many nested controls. **120fps is an optimization target, not a
guarantee in this release.** Keep refraction off for baseline interaction tests.
No idle rendering loop is added by the provider.

Source attribution is in the package NOTICE and upstream Apache license. The
package intentionally includes no showcase photography, routing, site layout or
remote service dependency. It does include the grain resource and example graphic.
