# FORM Glass UI

Reusable React controls using the exact material and interaction implementation
shared with FORM's glass studies. This is a local, private npm package; it is not
published to a registry. Tested peer runtime: React / ReactDOM 18.3.1.

## Install

```sh
npm install /path/to/form-glass-react-0.1.0.tgz
```

Import the CSS once, after your application's reset. Mount one `GlassProvider`
per document. The host mount can have any ID; the provider marks its own root.

```tsx
import {useState} from 'react';
import {GlassProvider, Glass, GlassButton, GlassSelect,
        GlassSwitch, InstrumentNumber} from '@form-glass/react';
import '@form-glass/react/styles.css';

export function Controls() {
  const [count,setCount] = useState(0);
  const [on,setOn] = useState(false);
  const [mode,setMode] = useState('one');
  return <GlassProvider>
    <Glass fade={[]} style={{padding:24,width:300}}>
      <GlassButton onClick={()=>setCount(count+1)}>
        <InstrumentNumber value={count}/>
      </GlassButton>
      <GlassSwitch label="Enabled" checked={on} onChange={setOn}/>
      <GlassSelect label="Mode" value={mode} onChange={setMode}
        options={[{value:'one',label:'One'},{value:'two',label:'Two'}]}/>
    </Glass>
  </GlassProvider>;
}
```

Put photography, a map or artwork behind the controls to see the material. The
library leaves page layout and background content to the application.

## Defaults

| Setting | Default |
| --- | --- |
| Refraction | **Off**, opt in with `refractionEnabled` |
| Light material | blur 8px, brightness +40%, contrast 0.6, black text |
| Dark material | blur 8px, brightness −40%, contrast 1.4, white text |
| Grain | 25% on the refined 0–100 scale |
| Each channel's fade | distance 32px, mid −16px |
| Exemption field | strength 100%, distance 32px, **mid −32px** |
| Fade and motion curve | smootherstep |
| Content transition | blur 350ms, fade 150ms, blur limit 16px |
| Glass expand / contract | 250ms / 250ms |
| Dialog closed width / height | 100% / 100% |

Brightness is signed: 0 is neutral. Contrast 1 is neutral. Appearance uses the
same durations in reverse order. Old content, shell motion and new content start
together. Range dragging previews locally and commits material changes on release.

## Included APIs

- Material: `GlassProvider`, `useGlass`, `Glass`, `GlassButton`, `GlassLink`, `GlassField`.
- Controls: `GlassSelect`, `GlassSwitch`, `ParameterControl`, `DopplerRange`, `InstrumentNumber`.
- Motion and layout: `GlassDraggable`, `GlassScrollArea`, `GlassPageScrollbar`, `useContentTransition`.
- Contact objects: `GlassContactObjects`, `createContactObject`, `DEFAULT_CONTACT_EXEMPTION`.
- Typed presets: `readGlassDefaults`, `GLASS_PARAMETERS`, `DEFAULT_REFRACTION`,
  `DEFAULT_REFRACTION_ENABLED`, `REFRACTION_PARAMETERS`, `DEFAULT_ANIMATION_SETTINGS`, `ANIMATION_PARAMETERS`.
- Low-level integration: `foregroundText` and the exported geometry/settings types.

`Glass` accepts `shape="rectangle" | "capsule" | "flush"` and `fade` edges.
Omitting `fade` selects all four; `fade={[]}` is solid. Use `fade={['top','bottom']}`
or `fade={['left','right']}` for directional feathering. For a top-only feather
with two rounded bottom corners, set the corner tokens as shown in DEVELOPMENT.md.

## Run the included example

Copy `examples/consumer` to a new folder, then from that folder:

```sh
npm install /path/to/form-glass-react-0.1.0.tgz
npm install
npm run dev
```

The example uses an `application` mount ID, a procedural architectural background,
all principal control types, and a draggable contact object. It imports the package
by name and contains no imports from the original repository.

## Integration boundaries

This release is a **browser client UI**. Use a client-only boundary when integrating
with SSR frameworks. The runtime currently owns document-level material/theme
tokens, so independently themed providers in the same document are not supported.
Do not place a filter, mask or opacity below 1 on an ancestor of live glass: those
properties create a new backdrop root and can prevent nested glass from sampling
the scene. Give scroll viewports an explicit height. Contact objects use viewport
coordinates and must live under the same provider as the glass surfaces.

The implementation uses backdrop-filter, SVG displacement, native Popover and Web
Animations. Chromium/Edge is the reference browser; test your target browser before
shipping. Large overlapping animated panels remain expensive; 120fps is not a
guarantee. Refraction stays off until explicitly requested.

See **DEVELOPMENT.md** for the API contract, migration rules, animation examples,
build pipeline, validation and known limitations. Upstream attribution is preserved
in **NOTICE** and **licenses/**. Demonstration photographs are not bundled.
