import {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {GlassProvider,Glass,GlassButton,GlassSelect,GlassSwitch,GlassScrollArea,GlassPageScrollbar,InstrumentNumber,ParameterControl,GlassDraggable,GlassContactObjects,createContactObject,useGlass,DEFAULT_REFRACTION_ENABLED} from '@form-glass/react';
import '@form-glass/react/styles.css';
import './page.css';

function Demo(){
  const [theme,setTheme]=useState<'light'|'dark'>('light'),[blur,setBlur]=useState(8),[refraction,setRefraction]=useState<boolean>(DEFAULT_REFRACTION_ENABLED);
  return <GlassProvider theme={theme} values={{blur}} refractionEnabled={refraction}>
    <div className="example-backdrop"/>
    <header><h1>FORM / Glass UI</h1><p>Installed package. Independent mount. Same material.</p></header>
    <div className="example-grid">
      <Glass className="example-card" fade={[]}><h2>Material</h2><ParameterControl label="Blur" value={blur} min={0} max={64} step={1} unit="px" onChange={setBlur}/><GlassSwitch label="Refraction" checked={refraction} onChange={setRefraction}/><GlassSelect label="Theme" value={theme} options={[{value:'light',label:'Light'},{value:'dark',label:'Dark'}]} onChange={v=>setTheme(v as 'light'|'dark')}/></Glass>
      <Counter/>
      <Glass className="example-card example-vertical" shape="flush" fade={['top','bottom']}><h2>Top / bottom</h2><p>Only vertical edges feather.</p></Glass>
      <Glass className="example-card example-horizontal" shape="flush" fade={['left','right']}><h2>Left / right</h2><p>Only horizontal edges feather.</p></Glass>
      <Glass className="example-card" fade={[]}><h2>Fine scroll rail</h2><GlassScrollArea label="Scroll sample items" viewportClassName="example-scroll">{Array.from({length:14},(_,i)=><p key={i}>Item {String(i+1).padStart(2,'0')} / Typography, image, material.</p>)}</GlassScrollArea></Glass>
      <Defaults/>
    </div>
    <Movable/>
    <Objects/>
    <GlassPageScrollbar/>
  </GlassProvider>;
}
function Counter(){const [count,setCount]=useState(0);return <GlassButton className="example-card example-counter" onClick={()=>setCount(count+1)} aria-label="Increase counter"><InstrumentNumber value={count}/><span>Four rounded corners</span></GlassButton>;}
function Defaults(){const {values,refractionEnabled}=useGlass();return <Glass className="example-card" fade={[]}><h2>Shared defaults</h2><p>Brightness: {values.brightness}%</p><p>Contrast: {values.contrast}</p><p>Grain: {values.grain}%</p><p>Refraction: {refractionEnabled?'on':'off'}</p><p>Exemption mid: −32 px</p></Glass>;}
function Movable(){const [position,setPosition]=useState({x:44,y:540});return <GlassDraggable position={position} onPositionChange={setPosition} label="Move across the viewport"><h2>Move.</h2><p>Pointer / arrow keys</p></GlassDraggable>;}
function Objects(){const [objects,setObjects]=useState(()=>[createContactObject({id:'poster',label:'Contact poster',src:new URL('../assets/contact-poster.svg',import.meta.url).href,x:500,y:370,width:150,height:100})]);return <GlassContactObjects objects={objects} onChange={setObjects}/>;}
createRoot(document.getElementById('application')!).render(<Demo/>);
